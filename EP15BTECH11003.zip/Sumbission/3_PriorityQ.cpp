#include<iostream>
#include<cstdio>

#define MAX_SIZE 1000

using namespace std;

int getElement(){
    int element;
    cout<<endl<<"Enter an element(int): ";
    cin>>element;
    cout<<endl;
    return element;
}

char command(){
    char inp;
    cout<<"\n-Press 'i' to insert an element\n-Press 'x' to extract the top of the Priority Queue\n-Press 's' to sort the Priority Queue (and quit)\n-Press 'd' to display the Queue inorder (for debugging)\n-Press 'q' to quit\n>>>> ";
    cin>>inp;
    return inp;
}


//--------------------------------------------------------------Class Definition------------------------------------------------------------------------


class heap{
protected:
    int heapSize=0,*heapArr=NULL;
public:
    heap(){
        cout<<"Enter the number of elements in the heap: ";
        cin>>heapSize;
        heapArr = new int[MAX_SIZE];
        cout<<"Enter a space separated list of "<<heapSize<<" integers to create a heap: ";
        for(int i=0;i<heapSize;i++)cin>>heapArr[i];
        buildHeap();
    }
    void inorder(int index = 0){
        if(index >= heapSize)return;
        inorder(left(index));
        cout<<heapArr[index]<<" ";
        inorder(right(index));
        return;
    }

    void heapSort(){
        int originalSize = heapSize,temp;
        for(int i = heapSize-1; i >0; i--){
            temp = heapArr[i];
            heapArr[i] = heapArr[0];
            heapArr[0] = temp;
            heapSize--;
            heapify(0);
        }
        heapSize = originalSize;
        for(int i = heapSize -1 ; i > 0; i--) cout<<heapArr[i]<<" ";
    }
    int extTop(){
        if(heapSize == 0){
            cout<<"Queue empty >>";
            return -1;
        }
        int output = heapArr[0];
        heapArr[0] = heapArr[heapSize-1];
        heapSize--;
        heapify(0);
        return output;
    }
    void insert(int x){
        if(heapSize + 1 >= MAX_SIZE){
            cout<<"Heap is full";
            return;
        }
        heapArr[heapSize] = x;
        int index = heapSize;
        while(index != 0){
            int p;
            if(index%2 == 0 )p = index/2 -1;
            else p = index/2;
            if(heapArr[p] > heapArr[index]){
                int temp = heapArr[p];
                heapArr[p] = heapArr[index];
                heapArr[index] = temp;
            }
            index = p;
        }
        heapSize++;
    }

private:
    int left(int x){return (2*x + 1);}
    int right(int x){return (2*x +2);}
    void heapify(int x){
        int smallest, l=left(x), r= right(x);
        if(l <heapSize && heapArr[x] > heapArr[l]) smallest = l;
        else smallest = x;
        if(r <heapSize && heapArr[smallest] > heapArr[r]) smallest = r;
        if(smallest != x){
            int temp = heapArr[smallest];
            heapArr[smallest] = heapArr [x];
            heapArr[x] = temp;
            heapify(smallest);
        }
    }
    void buildHeap(){
        for(int i = (heapSize-1)/2; i >= 0; i--)heapify(i);
    }
};


int main(){
    heap A;
    while(1){
        switch(command()){
            case 'i':
                A.insert(getElement());
                break;

            case 'x':
                cout<<A.extTop();
                break;

            case 's':
                A.heapSort();
                return 0;

            case 'd':                                                           //debugging
                cout<<endl<<"\t";
                A.inorder();
                cout<<endl;
                break;

            case 'q':
                return 0;

            default:
                cout<<"Please give a valid input..."<<endl;
                break;
        }
    }
    return 0;
}
